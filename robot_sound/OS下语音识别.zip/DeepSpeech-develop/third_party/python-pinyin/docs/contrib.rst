.. _contrib:

contrib
========

.. _tone_convert:

拼音转换
--------

.. autofunction:: pypinyin.contrib.tone_convert.to_normal
.. autofunction:: pypinyin.contrib.tone_convert.to_tone
.. autofunction:: pypinyin.contrib.tone_convert.to_tone2
.. autofunction:: pypinyin.contrib.tone_convert.to_tone3

.. autofunction:: pypinyin.contrib.tone_convert.tone_to_normal
.. autofunction:: pypinyin.contrib.tone_convert.tone_to_tone2
.. autofunction:: pypinyin.contrib.tone_convert.tone_to_tone3

.. autofunction:: pypinyin.contrib.tone_convert.tone2_to_normal
.. autofunction:: pypinyin.contrib.tone_convert.tone2_to_tone
.. autofunction:: pypinyin.contrib.tone_convert.tone2_to_tone3

.. autofunction:: pypinyin.contrib.tone_convert.tone3_to_normal
.. autofunction:: pypinyin.contrib.tone_convert.tone3_to_tone
.. autofunction:: pypinyin.contrib.tone_convert.tone3_to_tone2


V2UMixin
---------

.. autoclass:: pypinyin.contrib.uv.V2UMixin


NeutralToneWith5Mixin
-----------------------

.. autoclass:: pypinyin.contrib.neutral_tone.NeutralToneWith5Mixin
