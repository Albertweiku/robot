安装
======

可以使用 pip 进行安装:

.. code-block:: bash

    $ pip install pypinyin

easy_install 安装:

.. code-block:: bash

    $ easy_install pypinyin

源码安装:

.. code-block:: bash

    $ python setup.py install
