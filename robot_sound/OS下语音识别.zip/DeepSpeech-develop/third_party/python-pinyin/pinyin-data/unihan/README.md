# Unihan Database

http://www.unicode.org/charts/unihan.html

Update Unihan databse:

```
make update
```
