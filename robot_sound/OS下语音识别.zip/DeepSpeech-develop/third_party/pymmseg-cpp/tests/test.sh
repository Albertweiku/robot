


echo "hello world" | ./bin/pymmseg
echo "我是中国人武汉长江大桥" | ./bin/pymmseg
echo "我是,中国人。武汉长江大桥" | ./bin/pymmseg
echo "我是中国人。hello.武汉长江大桥" | ./bin/pymmseg
echo "我是中国人,hello.武汉长江大桥。" | ./bin/pymmseg
echo "我是中国人，hello.武汉长江大桥。" | ./bin/pymmseg
