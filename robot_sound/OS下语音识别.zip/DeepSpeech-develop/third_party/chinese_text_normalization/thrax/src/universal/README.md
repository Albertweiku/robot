# Language-universal grammar definitions

This directory contains various language-universal grammar definitions.
