# Fast Transformers for Speech

- Conformer
- Transformer

## Reference

* https://github.com/NVIDIA/FasterTransformer.git
* https://github.com/idiap/fast-transformers
