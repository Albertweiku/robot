# multi-cn

This is a Chinese speech recognition recipe that trains on all Chinese corpora on OpenSLR, including:

* Aidatatang (140 hours)
* Aishell (151 hours)
* MagicData (712 hours)
* Primewords (99 hours)
* ST-CMDS (110 hours)
* THCHS-30 (26 hours)
* optional AISHELL2 (~1000 hours) if available
