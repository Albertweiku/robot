# TIMIT

* s1 u2 model with phone unit
