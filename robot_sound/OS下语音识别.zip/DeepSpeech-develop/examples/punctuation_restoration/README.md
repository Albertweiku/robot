# Punctation Restoration

Please using [PaddleSpeechTask](https://github.com/745165806/PaddleSpeechTask] to do this task.
