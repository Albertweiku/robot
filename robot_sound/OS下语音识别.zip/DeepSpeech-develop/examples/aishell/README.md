# ASR

* s0 for deepspeech2 offline
* s1 for u2
