* s0 for deepspeech2
* s1 for U2
