# TED En -> Zh

* t0 for u2 speech translation
