text_correct.txt: https://github.com/shibing624/pycorrector/raw/master/tests/test_file.txt
custom_confusion.txt: https://github.com/shibing624/pycorrector/raw/master/tests/custom_confusion.txt
