# Benchmark Test

## Data

* Aishell

## Docker

```
registry.baidubce.com/paddlepaddle/paddle   2.1.1-gpu-cuda10.2-cudnn7   59d5ec1de486  
```
