import paddleaudio

if __name__ == '__main__':
    paddleaudio.load('./test_audio.m4a')
