# ASD:  anormaly sound detection
