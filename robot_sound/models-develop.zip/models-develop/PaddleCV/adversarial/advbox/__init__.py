"""
   A set of tools for generating adversarial example on paddle platform
"""
