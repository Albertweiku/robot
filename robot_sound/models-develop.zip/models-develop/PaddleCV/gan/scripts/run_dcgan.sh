python train.py --model_net DCGAN --dataset mnist --noise_size 100 --batch_size 128 --epoch 20 --output ./output/dcgan/ >log_out 2>log_err
