python infer.py --model_net AttGAN --init_model output/attgan/checkpoints/119/ --dataset_dir ./data/celeba/ --image_size 128 --output ./infer_result/attgan/
