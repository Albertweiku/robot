python infer.py --model_net DCGAN --init_model ./output/dcgan/checkpoints/19/ --n_samples 32 --noise_size 100 --output ./infer_result/dcgan/
