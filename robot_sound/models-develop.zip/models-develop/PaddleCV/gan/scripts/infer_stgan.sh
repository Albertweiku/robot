python infer.py --model_net STGAN --init_model ./output/stgan/checkpoints/49/ --dataset_dir ./data/celeba/ --image_size 128 --use_gru True --output ./infer_result/stgan/
