python train.py --model_net CGAN --dataset mnist --noise_size 100 --batch_size 121 --epoch 20 --output ./output/cgan/ >log_out 2>log_err
